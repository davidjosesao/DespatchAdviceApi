# Despatch Advice API

A serverless API for generating UBL 2.1 compliant Despatch Advice documents.

## Overview

This API provides endpoints for creating, retrieving, updating, and deleting Despatch Advice documents. It uses AWS Lambda, API Gateway, S3, and DynamoDB to provide a scalable, serverless solution.

## Architecture

- **API Gateway**: Exposes the REST endpoints
- **Lambda**: Handles the business logic
- **S3**: Stores the generated UBL XML documents
- **DynamoDB**: Stores metadata for the Despatch Advice documents

## Setup Instructions

### Prerequisites

- Node.js 16.x or later
- AWS CLI configured with appropriate credentials
- Serverless Framework

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```

### Local Development

Run the local development server:
```
npm start
```

This will start a local server at http://localhost:3000 that simulates the API Gateway and Lambda environment.

### Testing

Run the test suite:
```
npm test
```

### Deployment

Deploy to AWS:
```
npm run deploy
```

To specify a stage and region:
```
npm run deploy -- --stage prod --region us-west-2
```

## API Endpoints

### Create a new despatch advice

**Route**: POST /despatch-advice

**Request Body**:
```json
{
  "orderId": "ORD-12345",
  "supplier": {
    "name": "Supplier Inc.",
    "address": "123 Supplier St, Supplier City",
    "contact": "+1234567890"
  },
  "buyer": {
    "name": "Buyer Corp.",
    "address": "456 Buyer Ave, Buyer City",
    "contact": "+0987654321"
  },
  "items": [
    {
      "productId": "PROD-001",
      "description": "Product One",
      "quantity": 10,
      "unit": "EA"
    }
  ],
  "despatchDate": "2025-03-15",
  "deliveryLocation": "789 Delivery Rd, Delivery City"
}
```

**Response**:
```json
{
  "despatchId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "status": "CREATED",
  "documentUrl": "https://despatch-advice-documents-dev.s3.amazonaws.com/f47ac10b-58cc-4372-a567-0e02b2c3d479.xml",
  "message": "Despatch advice created successfully"
}
```

### Get a despatch advice

**Route**: GET /despatch-advice/{despatchId}

**Response**:
```json
{
  "despatchId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "orderId": "ORD-12345",
  "supplier": {
    "name": "Supplier Inc.",
    "address": "123 Supplier St, Supplier City",
    "contact": "+1234567890"
  },
  "buyer": {
    "name": "Buyer Corp.",
    "address": "456 Buyer Ave, Buyer City",
    "contact": "+0987654321"
  },
  "items": [
    {
      "productId": "PROD-001",
      "description": "Product One",
      "quantity": 10,
      "unit": "EA"
    }
  ],
  "despatchDate": "2025-03-15",
  "deliveryLocation": "789 Delivery Rd, Delivery City",
  "status": "CREATED",
  "documentUrl": "https://despatch-advice-documents-dev.s3.amazonaws.com/f47ac10b-58cc-4372-a567-0e02b2c3d479.xml"
}
```

### Update a despatch advice

**Route**: PUT /despatch-advice

**Request Body**:
```json
{
  "despatchId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "orderId": "ORD-12345",
  "supplier": {
    "name": "Updated Supplier Inc.",
    "address": "123 Updated St, Supplier City",
    "contact": "+1234567890"
  },
  "buyer": {
    "name": "Buyer Corp.",
    "address": "456 Buyer Ave, Buyer City",
    "contact": "+0987654321"
  },
  "items": [
    {
      "productId": "PROD-001",
      "description": "Updated Product One",
      "quantity": 15,
      "unit": "EA"
    }
  ],
  "despatchDate": "2025-03-16",
  "deliveryLocation": "789 Delivery Rd, Delivery City"
}
```

**Response**:
```json
{
  "despatchId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "status": "UPDATED",
  "message": "Despatch advice updated successfully"
}
```

### Delete a despatch advice

**Route**: DELETE /despatch-advice/{despatchId}

**Response**:
```json
{
  "despatchId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "status": "DELETED",
  "message": "Despatch advice deleted successfully"
}
```

## Error Handling

The API returns appropriate HTTP status codes and error messages for various scenarios:

- **400 Bad Request**: Invalid or missing parameters
- **404 Not Found**: Despatch advice not found
- **500 Internal Server Error**: Server-side processing error

## UBL 2.1 Compliance

The generated XML documents follow the UBL 2.1 standard for Despatch Advice documents. The schema validation is performed before storing the document.