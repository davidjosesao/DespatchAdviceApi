const { postDespatch } = require('./handlers/postDespatch');
const { getDespatch } = require('./handlers/getDespatch');
const { patchDespatch } = require('./handlers/patchDespatch');

exports.handler = async (event) => {
  const routeKey = `${event.httpMethod} ${event.resource}`;
  
  switch (routeKey) {
    case 'POST /despatch-advice':
      return postDespatch(event);
    case 'GET /despatch-advice/{id}':
      return getDespatch(event);
    case 'PATCH /despatch-advice/{id}':
      return patchDespatch(event);
    default:
      return {
        statusCode: 404,
        body: JSON.stringify({ error: 'Route not found' })
      };
  }
};