const { getDespatchAdviceFromDB, saveDespatchAdviceToDB } = require('../database/dynamodbClient');
const { despatchAdvice } = require('../create');

exports.handler = async (event) => {
  try {
    const despatchId = event.pathParameters.despatchId;
    const updatedData = JSON.parse(event.body);
    const existing = await getDespatchAdviceFromDB(despatchId);

    if (!existing) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: 'Despatch Advice not found' })
      };
    }

    // Supplier Update
    if (updatedData.supplier) {
      existing.jsonData.supplier = {
        ...existing.jsonData.supplier,
        ...updatedData.supplier,
        address: {
          ...existing.jsonData.supplier.address,
          ...(updatedData.supplier.address || {})
        },
        contact: updatedData.supplier.contact ? {
          ...existing.jsonData.supplier.contact,
          ...updatedData.supplier.contact
        } : existing.jsonData.supplier.contact
      };
    }

    // Products Update
    if (updatedData.products) {
      if (!Array.isArray(updatedData.products)) {
        return {
          statusCode: 400,
          body: JSON.stringify({ error: 'Products must be an array' })
        };
      }
      existing.jsonData.products = updatedData.products;
    }

    // Other Fields
    for (const [key, value] of Object.entries(updatedData)) {
      if (key !== 'supplier' && key !== 'products') {
        existing.jsonData[key] = value;
      }
    }

    // --- Regenerate XML (reusing create.js) ---
    const updatedXML = await despatchAdvice(existing.jsonData);
    existing.xml = updatedXML;

    await saveDespatchAdviceToDB(existing);

    return {
      statusCode: 200,
      body: JSON.stringify({
        despatchId: existing.despatchId,
        xml: updatedXML
      })
    };
  } catch (error) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: error.message })
    };
  }
};