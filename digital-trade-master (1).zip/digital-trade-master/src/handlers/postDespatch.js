const { despatchAdvice } = require('../create');
const { saveDespatchAdviceToDB } = require('../database/dynamodbClient');

exports.handler = async (event) => {
  try {
    const jsonData = JSON.parse(event.body);
    const xml = await despatchAdvice(jsonData);
    const despatchId = jsonData.despatchId || `DA-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    await saveDespatchAdviceToDB({ despatchId, xml, jsonData });

    return {
      statusCode: 201,
      body: JSON.stringify({ id: despatchId, xml })
    };
  } catch (error) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: error.message })
    };
  }
};