const { getDespatchAdviceFromDB } = require('../database/dynamodbClient');

exports.handler = async (event) => {
  try {
    const despatchId = event.pathParameters.despatchId;
    const item = await getDespatchAdviceFromDB(despatchId);
    
    return item 
      ? { statusCode: 200, body: JSON.stringify(item) }
      : { statusCode: 404, body: JSON.stringify({ error: 'Not found' }) };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};