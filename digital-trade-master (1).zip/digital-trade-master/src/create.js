const { create } = require('xmlbuilder2');

/**
 * Converts JSON data to UBL 2.1 compliant Despatch Advice XML
 * @param {Object} jsonData - JSON data containing order and shipment details
 * @returns {Promise<string>} - UBL formatted XML string
 */
async function despatchAdvice(jsonData) {
  try {
    // Validate required fields and data types
    validateInput(jsonData);

    // Generate unique despatch ID if not provided
    const despatchId = jsonData.despatchId || `DA-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    // Create the UBL structure
    const ublDocument = {
      DespatchAdvice: {
        '@xmlns': 'urn:oasis:names:specification:ubl:schema:xsd:DespatchAdvice-2',
        '@xmlns:cac': 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2',
        '@xmlns:cbc': 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2',
        'cbc:UBLVersionID': '2.1',
        'cbc:ID': despatchId,
        'cbc:IssueDate': new Date().toISOString().split('T')[0],
        'cbc:DespatchAdviceTypeCode': 'NA',
        'cbc:Note': jsonData.note || 'Despatch Advice for order ' + jsonData.orderId,
        'cac:OrderReference': {
          'cbc:ID': jsonData.orderId
        },
        'cac:DespatchSupplierParty': createPartyStructure(jsonData.supplier, 'Supplier'),
        'cac:DeliveryCustomerParty': createPartyStructure(jsonData.buyer, 'Customer'),
        'cac:Shipment': createShipmentStructure(jsonData),
        'cac:DespatchLine': createDespatchLines(jsonData.products)
      }
    };

    // Convert to XML using xmlbuilder2
    const xml = create(ublDocument).end({ prettyPrint: true });
    return xml;
  } catch (error) {
    throw new Error(error.message); // Propagate the error for handling in the route
  }
}

/**
 * Validates that all required fields are present and have the correct data types
 * @param {Object} jsonData - Input JSON data
 */
function validateInput(jsonData) {
  const requiredFields = ['orderId', 'supplier', 'buyer', 'products', 'orderDate', 'deliveryDate', 'deliveryLocation'];

  // Check for missing required fields
  for (const field of requiredFields) {
    if (!jsonData[field]) {
      throw new Error(`Missing required field: ${field}`);
    }
  }

  // Validate supplier fields
  const supplierFields = ['name', 'address', 'contact'];
  for (const field of supplierFields) {
    if (!jsonData.supplier[field]) {
      throw new Error(`Missing required field: supplier.${field}`);
    }
  }

  // Validate buyer fields
  const buyerFields = ['name', 'address', 'contact'];
  for (const field of buyerFields) {
    if (!jsonData.buyer[field]) {
      throw new Error(`Missing required field: buyer.${field}`);
    }
  }

  // Validate products
  if (!Array.isArray(jsonData.products) || jsonData.products.length === 0) {
    throw new Error('Products must be a non-empty array');
  }

  // Validate each product
  const productFields = ['name', 'description', 'quantity', 'unitMeasure'];
  jsonData.products.forEach((product, index) => {
    for (const field of productFields) {
      if (!product[field]) {
        throw new Error(`Missing required field in product ${index + 1}: ${field}`);
      }
    }

    // Validate quantity is a number
    if (typeof product.quantity !== 'number') {
      throw new Error(`Invalid quantity for product ${index + 1}: must be a number`);
    }
  });
}
/**
 * Creates UBL party structure for supplier or buyer
 * @param {Object} partyData - Party information (supplier or buyer)
 * @param {string} roleCode - Role code for the party
 * @returns {Object} - UBL party structure
 */
function createPartyStructure(partyData, roleCode) {
  return {
    'cac:Party': {
      'cac:PartyIdentification': {
        'cbc:ID': partyData.id || `ID-${partyData.name}`
      },
      'cac:PartyName': {
        'cbc:Name': partyData.name
      },
      'cac:PostalAddress': {
        'cbc:StreetName': partyData.address.street || '',
        'cbc:CityName': partyData.address.city || '',
        'cbc:PostalZone': partyData.address.postalCode || '',
        'cbc:CountrySubentity': partyData.address.state || '',
        'cac:Country': {
          'cbc:IdentificationCode': partyData.address.countryCode || '',
          'cbc:Name': partyData.address.country || ''
        }
      },
      'cac:Contact': {
        'cbc:Name': partyData.contact.name || '',
        'cbc:Telephone': partyData.contact.phone || '',
        'cbc:ElectronicMail': partyData.contact.email || ''
      }
    }
  };
}

/**
 * Creates UBL shipment structure
 * @param {Object} jsonData - Input JSON data
 * @returns {Object} - UBL shipment structure
 */
function createShipmentStructure(jsonData) {
  return {
    'cbc:ID': jsonData.shipmentId || `SH-${jsonData.orderId}`,
    'cbc:Information': jsonData.shipmentInfo || '',
    'cbc:ShippingPriorityLevelCode': jsonData.priorityLevel || 'Standard',
    'cbc:HandlingCode': jsonData.handlingCode || '',
    'cac:ShipmentStage': {
      'cbc:TransportModeCode': jsonData.transportMode || 'Road',
      'cac:TransitPeriod': {
        'cbc:StartDate': jsonData.orderDate,
        'cbc:EndDate': jsonData.deliveryDate
      }
    },
    'cac:Delivery': {
      'cac:DeliveryAddress': {
        'cbc:StreetName': jsonData.deliveryLocation.street || '',
        'cbc:CityName': jsonData.deliveryLocation.city || '',
        'cbc:PostalZone': jsonData.deliveryLocation.postalCode || '',
        'cbc:CountrySubentity': jsonData.deliveryLocation.state || '',
        'cac:Country': {
          'cbc:IdentificationCode': jsonData.deliveryLocation.countryCode || '',
          'cbc:Name': jsonData.deliveryLocation.country || ''
        }
      },
      'cac:RequestedDeliveryPeriod': {
        'cbc:StartDate': jsonData.deliveryDate,
        'cbc:EndDate': jsonData.deliveryDateEnd || jsonData.deliveryDate
      },
      'cac:EstimatedDeliveryPeriod': {
        'cbc:StartDate': jsonData.estimatedDeliveryDateStart || jsonData.deliveryDate,
        'cbc:EndDate': jsonData.estimatedDeliveryDateEnd || jsonData.deliveryDate
      }
    },
    'cac:TransportHandlingUnit': {
      'cbc:ID': jsonData.trackingId || '',
      'cbc:TransportHandlingUnitTypeCode': jsonData.packageType || 'Box'
    }
  };
}

/**
 * Creates UBL despatch lines for products
 * @param {Array} products - Array of product information
 * @returns {Array} - Array of UBL despatch line structures
 */
function createDespatchLines(products) {
  return products.map((product, index) => {
    return {
      'cbc:ID': product.id || `${index + 1}`,
      'cbc:DeliveredQuantity': {
        '#': product.quantity,
        '@unitCode': product.unitMeasure
      },
      'cac:OrderLineReference': {
        'cbc:LineID': product.orderLineId || `${index + 1}`
      },
      'cac:Item': {
        'cbc:Name': product.name,
        'cbc:Description': product.description,
        'cac:SellersItemIdentification': {
          'cbc:ID': product.sellerId || `SELL-${index + 1}`
        },
        'cac:StandardItemIdentification': {
          'cbc:ID': product.standardId || `STD-${index + 1}`
        }
      }
    };
  });
}

module.exports = { despatchAdvice };