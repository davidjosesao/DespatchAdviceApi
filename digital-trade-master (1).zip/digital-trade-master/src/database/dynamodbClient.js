// database/dynamodbClient.js

const AWS = require('aws-sdk');
AWS.config.update({ region: 'us-east-1' });  // Set your region

const dynamoDB = new AWS.DynamoDB.DocumentClient();  // Use DocumentClient for easier interaction

// Save a despatch advice to DynamoDB
async function saveDespatchAdviceToDB(despatch) {
  const params = {
    TableName: 'DespatchAdvices',
    Item: {
      despatchId: despatch.despatchId,  // Unique despatchId
      ...despatch  // Add all other data fields here
    },
  };

  try {
    await dynamoDB.put(params).promise();
    console.log('Despatch advice saved to DynamoDB');
  } catch (error) {
    console.error('Error saving despatch advice to DynamoDB:', error);
    throw new Error('Could not save despatch advice to DynamoDB');
  }
}

// Get a despatch advice from DynamoDB by despatchId
async function getDespatchAdviceFromDB(despatchId) {
  const params = {
    TableName: 'DespatchAdvices',
    Key: { despatchId },  // Query by despatchId (primary key)
  };

  try {
    const result = await dynamoDB.get(params).promise();

    // If the despatch advice exists, return it
    if (result.Item) {
      return result.Item;
    } else {
      return null;  // Return null if the despatchId doesn't exist in the table
    }
  } catch (error) {
    console.error('Error retrieving despatch advice from DynamoDB:', error);
    throw new Error('Could not retrieve despatch advice from DynamoDB');
  }
}

module.exports = { saveDespatchAdviceToDB, getDespatchAdviceFromDB };