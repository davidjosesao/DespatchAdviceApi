const express = require('express');
const bodyParser = require('body-parser');
const { despatchAdvice } = require('./create');
const { saveDespatchAdviceToDB, getDespatchAdviceFromDB } = require('./database/dynamodbClient');

const app = express();
app.use(bodyParser.json());

// POST /despatch-advice
app.post('/despatch-advice', async (req, res) => {
  try {
    const jsonData = req.body;

    if (!jsonData.orderId || !jsonData.supplier || !jsonData.buyer || !jsonData.products) {
      throw new Error("Missing required fields");
    }

    const xml = await despatchAdvice(jsonData);
    const despatchId = jsonData.despatchId || `DA-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    // Construct the new despatch advice object
    const newDespatchAdvice = { despatchId, xml, jsonData };

    // Save the new despatch advice to DynamoDB
    await saveDespatchAdviceToDB(newDespatchAdvice);

    res.status(201).json({ id: despatchId, xml });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// PATCH /despatch-advice/:despatchId
app.patch('/despatch-advice/:despatchId', async (req, res) => {
  try {
    const despatchId = req.params.despatchId;
    const updatedData = req.body;

    if (Object.keys(updatedData).length === 0) {
      return res.status(400).json({ error: "No valid fields provided for update." });
    }

    const existingDespatchAdvice = await getDespatchAdviceFromDB(despatchId);
    if (!existingDespatchAdvice) {
      return res.status(404).json({ error: 'Despatch Advice not found' });
    }

    // --- Handle Supplier Update ---
    if (updatedData.supplier) {
      const { name, address, contact } = updatedData.supplier;

      // Only require address if supplier is being updated with new values
      if (name && !address) {
        return res.status(400).json({ error: 'Missing required field(s) in supplier object' });
      }

      // Merge supplier data, preserving existing fields when not provided
      existingDespatchAdvice.jsonData.supplier = {
        ...existingDespatchAdvice.jsonData.supplier,
        ...updatedData.supplier,
        address: {
          ...existingDespatchAdvice.jsonData.supplier.address,
          ...(updatedData.supplier.address || {})
        },
        contact: updatedData.supplier.contact ? {
          ...existingDespatchAdvice.jsonData.supplier.contact,
          ...updatedData.supplier.contact
        } : existingDespatchAdvice.jsonData.supplier.contact
      };
    }

    // --- Handle Products Update ---
    if (updatedData.products) {
      const products = updatedData.products;

      if (!Array.isArray(products)) {
        return res.status(400).json({ error: 'Products must be an array' });
      }

      for (let i = 0; i < products.length; i++) {
        const product = products[i];
        if (typeof product.quantity !== 'number') {
          return res.status(400).json({ error: `Product ${i + 1} quantity must be a number` });
        }
        // Only require unitMeasure if it's a new product or being explicitly updated
        if (product.unitMeasure === undefined && !existingDespatchAdvice.jsonData.products[i]) {
          return res.status(400).json({ error: `Missing required field in product ${i + 1}: unitMeasure` });
        }
      }

      existingDespatchAdvice.jsonData.products = products;
    }

    // --- Update Other Fields ---
    for (const [key, value] of Object.entries(updatedData)) {
      if (key !== 'supplier' && key !== 'products') {
        existingDespatchAdvice.jsonData[key] = value;
      }
    }

    // --- Regenerate XML ---
    const updatedXML = await despatchAdvice(existingDespatchAdvice.jsonData);
    existingDespatchAdvice.xml = updatedXML;

    // Save the updated despatch advice to the database
    await saveDespatchAdviceToDB(existingDespatchAdvice);

    // Return the updated response
    res.status(200).json({
      despatchId: existingDespatchAdvice.despatchId,
      xml: updatedXML
    });
  } catch (error) {
    console.error('PATCH error:', error);
    res.status(400).json({ error: error.message });
  }
});


// GET /
app.get("/", (req, res) => {
  res.status(200).json({ message: "Hello World!" });
});

module.exports = { app };