const request = require('supertest');
const { app } = require('../app');

jest.mock('../database/dynamodbClient', () => ({
  saveDespatchAdviceToDB: jest.fn().mockResolvedValue('mocked success'),
}));

describe('Despatch Advice Creation', () => {
  // Test Case 1: Successful creation of despatch advice
  test('despatch advice created successfully', async () => {
    const response = await request(app)
      .post('/despatch-advice')
      .send({
        orderId: '12345',
        supplier: {
          name: 'ABC Ltd.',
          address: { street: '123 Street', city: 'City', country: 'Country' },
          contact: { name: 'John Doe', phone: '123-456-7890', email: 'john@abc.com' }
        },
        buyer: {
          name: 'XYZ Corp.',
          address: { street: '456 Avenue', city: 'City', country: 'Country' },
          contact: { name: 'Jane Smith', phone: '987-654-3210', email: 'jane@xyz.com' }
        },
        products: [
          { name: 'Laptop', description: 'High-end laptop', quantity: 10, unitMeasure: 'pcs' }
        ],
        orderDate: '2023-10-01',
        deliveryDate: '2023-10-10',
        deliveryLocation: {
          street: '789 Delivery St',
          city: 'Delivery City',
          country: 'Country'
        }
      });

    expect(response.status).toBe(201);
    expect(response.body).toHaveProperty('id');
    expect(response.body).toHaveProperty('xml');
  });

  // Test Case 2: Missing required fields
  test('missing required fields', async () => {
    const response = await request(app)
      .post('/despatch-advice')
      .send({
        orderId: '12345',
        supplier: { name: 'ABC Ltd.' }, // Missing address and contact
        buyer: {
          name: 'XYZ Corp.',
          address: { street: '456 Avenue', city: 'City', country: 'Country' },
          contact: { name: 'Jane Smith', phone: '987-654-3210', email: 'jane@xyz.com' }
        },
        products: [
          { name: 'Laptop', description: 'High-end laptop', quantity: 10, unitMeasure: 'pcs' }
        ],
        orderDate: '2023-10-01', // Include orderDate
        deliveryDate: '2023-10-10', // Include deliveryDate
        deliveryLocation: { // Include deliveryLocation
          street: '789 Delivery St',
          city: 'Delivery City',
          country: 'Country'
        }
      });
  
    expect(response.status).toBe(400);
    expect(response.body).toEqual({
      error: 'Missing required field: supplier.address'
    });
  });

  // Test Case 3: Invalid data format
  test('invalid data format', async () => {
    const response = await request(app)
      .post('/despatch-advice')
      .send({
        orderId: '12345',
        supplier: {
          name: 'ABC Ltd.',
          address: { street: '123 Street', city: 'City', country: 'Country' },
          contact: { name: 'John Doe', phone: '123-456-7890', email: 'john@abc.com' }
        },
        buyer: {
          name: 'XYZ Corp.',
          address: { street: '456 Avenue', city: 'City', country: 'Country' },
          contact: { name: 'Jane Smith', phone: '987-654-3210', email: 'jane@xyz.com' }
        },
        products: [
          { name: 'Laptop', description: 'High-end laptop', quantity: 'ten', unitMeasure: 'pcs' } // Invalid quantity
        ],
        orderDate: '2023-10-01',
        deliveryDate: '2023-10-10',
        deliveryLocation: {
          street: '789 Delivery St',
          city: 'Delivery City',
          country: 'Country'
        }
      });

    expect(response.status).toBe(400);
    expect(response.body).toEqual({
      error: 'Invalid quantity for product 1: must be a number'
    });
  });
});