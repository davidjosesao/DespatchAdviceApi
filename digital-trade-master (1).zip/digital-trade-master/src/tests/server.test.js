const request = require('supertest');
const assert = require('assert');
const { app } = require('../app');

jest.mock('../database/dynamodbClient', () => ({
  saveDespatchAdviceToDB: jest.fn(),
  getDespatchAdviceFromDB: jest.fn(),
}));

const { saveDespatchAdviceToDB, getDespatchAdviceFromDB } = require('../database/dynamodbClient');

describe('GET /', () => {
  it('responds to the world', async function() {
    const res = await request(app)
      .get('/')
      .set('Accept', 'application/json');

    assert.equal(res.status, 200);
    assert.equal(res.type, 'application/json');
    assert.equal(res.body.message, 'Hello World!');
  });
});

describe('GET /404', () => {
  it('responds with a 404', async function() {
    const res = await request(app)
      .get('/404')
      .set('Accept', 'application/json');

    assert.equal(res.status, 404);
  });
});

describe('POST /despatch-advice', () => {
  it('responds with a 201 and valid xml for valid input', async function() {
    const validData = {
      orderId: '12345',
      supplier: {
        name: 'Supplier Name',
        address: { street: '123 Supplier St', city: 'City', postalCode: '12345', state: 'State', country: 'Country', countryCode: 'US' },
        contact: { name: 'Supplier Contact', phone: '1234567890', email: 'supplier@example.com' }
      },
      buyer: {
        name: 'Buyer Name',
        address: { street: '123 Buyer St', city: 'City', postalCode: '12345', state: 'State', country: 'Country', countryCode: 'US' },
        contact: { name: 'Buyer Contact', phone: '0987654321', email: 'buyer@example.com' }
      },
      products: [
        { id: 'P1', name: 'Product 1', description: 'Description 1', quantity: 10, unitMeasure: 'EA' }
      ],
      orderDate: '2025-03-31',
      deliveryDate: '2025-04-05',
      deliveryLocation: { street: '123 Delivery St', city: 'City', postalCode: '12345', state: 'State', country: 'Country', countryCode: 'US' }
    };

    // Mock the save function to simulate database save
    saveDespatchAdviceToDB.mockResolvedValueOnce({
      despatchId: '12345', // Simulate a valid despatchId
      xml: '<xml>some xml data</xml>' // Simulate some XML response
    });

    const res = await request(app)
      .post('/despatch-advice')
      .send(validData)
      .set('Accept', 'application/json');

    assert.equal(res.status, 201);
    assert(res.body.id);
    assert(res.body.xml);
  });

  it('responds with a 400 for invalid input', async function() {
    const invalidData = {}; // Invalid data

    const res = await request(app)
      .post('/despatch-advice')
      .send(invalidData)
      .set('Accept', 'application/json');

    assert.equal(res.status, 400);
    assert(res.body.error);
  });
});

describe('PATCH /despatch-advice/:despatchId', () => {
  let createdDespatchId;

  const mockDespatchAdvice = {
    orderId: '12345',
    supplier: {
      name: 'Supplier Name',
      address: { street: '123 Supplier St', city: 'City', postalCode: '12345', state: 'State', country: 'Country', countryCode: 'US' },
      contact: { name: 'Supplier Contact', phone: '1234567890', email: 'supplier@example.com' }
    },
    buyer: {
      name: 'Buyer Name',
      address: { street: '123 Buyer St', city: 'City', postalCode: '12345', state: 'State', country: 'Country', countryCode: 'US' },
      contact: { name: 'Buyer Contact', phone: '0987654321', email: 'buyer@example.com' }
    },
    products: [
      { id: 'P1', name: 'Product 1', description: 'Description 1', quantity: 10, unitMeasure: 'EA' }
    ],
    orderDate: '2025-03-31',
    deliveryDate: '2025-04-05',
    deliveryLocation: { street: '123 Delivery St', city: 'City', postalCode: '12345', state: 'State', country: 'Country', countryCode: 'US' }
  };

  beforeAll(async () => {
    const response = await request(app)
      .post('/despatch-advice')
      .send(mockDespatchAdvice);

    expect(response.status).toBe(201);
    createdDespatchId = response.body.id;
  });

  test('successfully updates the supplier name', async () => {
    getDespatchAdviceFromDB.mockResolvedValueOnce({
      despatchId: createdDespatchId,
      xml: '<original xml>',
      jsonData: { ...mockDespatchAdvice }
    });
  
    saveDespatchAdviceToDB.mockResolvedValueOnce();
  
    const response = await request(app)
      .patch(`/despatch-advice/${createdDespatchId}`)
      .send({
        supplier: {
          name: 'Deepak Ltd.',
          address: mockDespatchAdvice.supplier.address,
          contact: mockDespatchAdvice.supplier.contact
        }
      });
  
    expect(response.status).toBe(200);
    expect(response.body.despatchId).toBe(createdDespatchId);
    expect(response.body.xml).toContain('<cbc:Name>Deepak Ltd.</cbc:Name>');
  });

  test('fails when updating supplier with missing required fields', async () => {
    getDespatchAdviceFromDB.mockResolvedValueOnce({ ...mockDespatchAdvice, despatchId: createdDespatchId });

    const response = await request(app)
      .patch(`/despatch-advice/${createdDespatchId}`)
      .send({
        supplier: { name: 'Invalid Supplier' }
      });

    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Missing required field(s) in supplier object');
  });

  test('returns 404 for non-existent despatch advice', async () => {
    getDespatchAdviceFromDB.mockResolvedValueOnce(null);

    const response = await request(app)
      .patch('/despatch-advice/DOES_NOT_EXIST')
      .send({
        supplier: { name: 'Should not work' }
      });

    expect(response.status).toBe(404);
    expect(response.body.error).toBe('Despatch Advice not found');
  });

  test('returns 400 when updating with invalid data format', async () => {
    getDespatchAdviceFromDB.mockResolvedValueOnce({ ...mockDespatchAdvice, despatchId: createdDespatchId });

    const response = await request(app)
      .patch(`/despatch-advice/${createdDespatchId}`)
      .send({
        products: [
          { name: 'New Laptop', description: 'Updated high-end laptop', quantity: 'ten' }
        ]
      });

    expect(response.status).toBe(400);
    expect(response.body.error).toContain('must be a number');
  });

  test('successfully updates only the products without affecting other fields', async () => {
  getDespatchAdviceFromDB.mockResolvedValueOnce({
    despatchId: createdDespatchId,
    xml: '<original xml>',
    jsonData: { ...mockDespatchAdvice }
  });

  saveDespatchAdviceToDB.mockResolvedValueOnce(); 

  const response = await request(app)
    .patch(`/despatch-advice/${createdDespatchId}`)
    .send({
      products: [
        { name: 'Updated Product', description: 'Updated description', quantity: 5, unitMeasure: 'pcs' }
      ]
    });

  expect(response.status).toBe(200);
  expect(response.body.xml).toContain('<cbc:Name>Updated Product</cbc:Name>');
  });

  test('should return 400 when sending an empty request body', async () => {
    getDespatchAdviceFromDB.mockResolvedValueOnce({ ...mockDespatchAdvice, despatchId: createdDespatchId });

    const response = await request(app)
      .patch(`/despatch-advice/${createdDespatchId}`)
      .send({});

    expect(response.status).toBe(400);
    expect(response.body.error).toBe('No valid fields provided for update.');
  });
});